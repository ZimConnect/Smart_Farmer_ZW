
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'package:in_app_purchase/in_app_purchase.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SmartFarmerZW());
}

class SmartFarmerZW extends StatelessWidget {
  const SmartFarmerZW({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Farmer ZW',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF198754),
        scaffoldBackgroundColor: const Color(0xFFF5F7F2),
        cardTheme: const CardThemeData(margin: EdgeInsets.zero),
      ),
      home: const FarmShell(),
    );
  }
}

class FarmStore extends ChangeNotifier {
  static final FarmStore instance = FarmStore._();
  FarmStore._();
  late SharedPreferences prefs;
  bool pro = false;
  String farmer = 'Farmer';
  String province = 'Harare';
  List<Map<String, dynamic>> animals = [];
  List<Map<String, dynamic>> crops = [];
  List<Map<String, dynamic>> tasks = [];
  double expenses = 0;
  double sales = 0;

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    farmer = prefs.getString('farmer') ?? 'Farmer';
    province = prefs.getString('province') ?? 'Harare';
    pro = prefs.getBool('pro') ?? false;
    animals = _decode('animals');
    crops = _decode('crops');
    tasks = _decode('tasks');
    expenses = prefs.getDouble('expenses') ?? 0;
    sales = prefs.getDouble('sales') ?? 0;
    notifyListeners();
  }

  List<Map<String,dynamic>> _decode(String key) {
    final s = prefs.getString(key);
    if (s == null) return [];
    final data = jsonDecode(s);
    return (data as List).map((e) => Map<String,dynamic>.from(e)).toList();
  }

  Future<void> _save() async {
    await prefs.setString('farmer', farmer);
    await prefs.setString('province', province);
    await prefs.setBool('pro', pro);
    await prefs.setString('animals', jsonEncode(animals));
    await prefs.setString('crops', jsonEncode(crops));
    await prefs.setString('tasks', jsonEncode(tasks));
    await prefs.setDouble('expenses', expenses);
    await prefs.setDouble('sales', sales);
  }

  Future<void> setProfile(String name, String prov) async {
    farmer = name.trim().isEmpty ? 'Farmer' : name.trim();
    province = prov;
    await _save(); notifyListeners();
  }

  Future<void> addAnimal(Map<String,dynamic> a) async {
    animals.add(a); await _save(); notifyListeners();
  }
  Future<void> addCrop(Map<String,dynamic> c) async {
    crops.add(c); await _save(); notifyListeners();
  }
  Future<void> addTask(Map<String,dynamic> t) async {
    tasks.add(t); await _save(); notifyListeners();
  }
  Future<void> deleteAnimal(int i) async { animals.removeAt(i); await _save(); notifyListeners(); }
  Future<void> deleteCrop(int i) async { crops.removeAt(i); await _save(); notifyListeners(); }
  Future<void> deleteTask(int i) async { tasks.removeAt(i); await _save(); notifyListeners(); }

  Future<void> addExpense(double v) async { expenses += v; await _save(); notifyListeners(); }
  Future<void> addSale(double v) async { sales += v; await _save(); notifyListeners(); }
  Future<void> unlockDemoPro() async { pro = true; await _save(); notifyListeners(); }
}

final animalGroups = <String, List<String>>{
  'Cattle / Mombe': ['Mashona','Tuli','Brahman','Hereford','Angus','Simmental','Jersey','Holstein','Ayrshire','Beef cross','Dairy cross','Indigenous'],
  'Pigs': ['Large White','Landrace','Duroc','Hampshire','Crossbred','Indigenous'],
  'Sheep': ['Dorper','Merino','Katahdin','Indigenous','Crossbred'],
  'Goats / Mbudzi': ['Boer','Kalahari Red','Saanen','Angora','Indigenous','Crossbred'],
  'Rabbits': ['New Zealand White','Californian','Chinchilla','Rex','Local/Crossbred'],
  'Chickens': ['Broiler','Layer','Roadrunner/Indigenous','Dual purpose'],
  'Turkeys': ['Broad Breasted White','Bronze','Local'],
  'Ducks & Geese': ['Pekin','Muscovy','Khaki Campbell','Local Duck','Goose'],
  'Fish': ['Tilapia / Bream','Catfish / Muramba'],
  'Dogs': ['Mixed breed','German Shepherd','Boerboel','Rottweiler','Labrador','Other'],
  'Horses': ['Thoroughbred','Warmblood','Arabian','Local/Crossbred','Other'],
};

final cropCatalog = <String>[
  'Maize','Tobacco','Soybeans','Wheat','Sorghum','Pearl millet','Sunflower',
  'Groundnuts','Sugar beans','Cowpeas','Cotton','Irish potatoes','Sweet potatoes',
  'Tomato','Onion','Cabbage','Rape','Kale','Spinach','Carrot','Beetroot',
  'Green beans','Cucumber','Lettuce','Pepper','Pumpkin','Butternut','Watermelon',
  'Mango','Avocado','Citrus','Banana','Guava','Passion fruit','Strawberry'
];

final provinces = ['Harare','Bulawayo','Manicaland','Mashonaland Central','Mashonaland East',
  'Mashonaland West','Masvingo','Matabeleland North','Matabeleland South','Midlands'];

class FarmShell extends StatefulWidget {
  const FarmShell({super.key});
  @override State<FarmShell> createState() => _FarmShellState();
}
class _FarmShellState extends State<FarmShell> {
  int index = 0;
  final store = FarmStore.instance;
  @override void initState() { super.initState(); store.init(); }
  @override Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) => Scaffold(
        appBar: AppBar(
          title: const Text('Smart Farmer ZW', style: TextStyle(fontWeight: FontWeight.w800)),
          actions: [
            if (!store.pro) IconButton(
              tooltip: 'Go Pro',
              onPressed: () => showPro(context),
              icon: const Icon(Icons.workspace_premium),
            ),
            IconButton(onPressed: () => showProfile(context), icon: const Icon(Icons.person_outline)),
          ],
        ),
        body: IndexedStack(index: index, children: const [
          HomePage(), AnimalsPage(), CropsPage(), CalendarPage(), FarmPage()
        ]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index=v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.pets_outlined), selectedIcon: Icon(Icons.pets), label: 'Animals'),
            NavigationDestination(icon: Icon(Icons.eco_outlined), selectedIcon: Icon(Icons.eco), label: 'Crops'),
            NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Calendar'),
            NavigationDestination(icon: Icon(Icons.agriculture_outlined), selectedIcon: Icon(Icons.agriculture), label: 'My Farm'),
          ],
        ),
      ),
    );
  }

  void showProfile(BuildContext context) {
    final name = TextEditingController(text: store.farmer);
    String p = store.province;
    showDialog(context: context, builder: (_) => StatefulBuilder(builder: (context,set) => AlertDialog(
      title: const Text('Farmer profile'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText:'Farmer / farm name', prefixIcon: Icon(Icons.person))),
        const SizedBox(height:12),
        DropdownButtonFormField<String>(value:p, items: provinces.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
          onChanged:(v)=>set(()=>p=v!), decoration: const InputDecoration(labelText:'Province')),
      ]),
      actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),
        FilledButton(onPressed:(){store.setProfile(name.text,p);Navigator.pop(context);},child:const Text('Save'))],
    )));
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override Widget build(BuildContext context) {
    final s=FarmStore.instance;
    final profit=s.sales-s.expenses;
    return ListView(padding:const EdgeInsets.all(16),children:[
      Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(
        borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[Color(0xFF087F5B),Color(0xFF2F9E44)])),
        child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('Good ${DateTime.now().hour<12?'morning':DateTime.now().hour<18?'afternoon':'evening'}, ${s.farmer}',
            style:const TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.w800)),
          const SizedBox(height:6), Text('${s.province} • Zimbabwe',style:const TextStyle(color:Colors.white70)),
          const SizedBox(height:18),
          Row(children:[_stat('${s.animals.length}','Animals'),_stat('${s.crops.length}','Crops'),_stat('${s.tasks.length}','Tasks')]),
        ])),
      const SizedBox(height:16),
      if(!s.pro) Card(child:ListTile(
        leading:const CircleAvatar(child:Icon(Icons.workspace_premium)),
        title:const Text('Smart Farmer Pro',style:TextStyle(fontWeight:FontWeight.bold)),
        subtitle:const Text('Unlock unlimited animals, crops, reports & advanced tools — once-off $5.'),
        trailing:FilledButton(onPressed:()=>showPro(context),child:const Text('GO PRO')),
      )),
      const SizedBox(height:16),
      const Text("Today's farm centre",style:TextStyle(fontSize:19,fontWeight:FontWeight.w800)),
      const SizedBox(height:10),
      if(s.tasks.isEmpty) Card(child:ListTile(leading:const Icon(Icons.check_circle_outline),title:const Text('No tasks yet'),subtitle:const Text('Add breeding, feeding, vaccination or crop tasks from Calendar.')))
      else ...s.tasks.take(5).map((t)=>Card(child:ListTile(leading:Icon(Icons.notifications_active_outlined),
        title:Text(t['title']??''),subtitle:Text('${t['date']??''} • ${t['category']??''}')))),
      const SizedBox(height:16),
      GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisSpacing:10,mainAxisSpacing:10,
        children:[
          _quick(context,Icons.pets,'Add Animal',()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const AddAnimalPage()))),
          _quick(context,Icons.eco,'Add Crop',()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const AddCropPage()))),
          _quick(context,Icons.event,'Add Reminder',()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const AddTaskPage()))),
          _quick(context,Icons.calculate,'Farm Finance',()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const FinancePage()))),
        ]),
    ]);
  }
  Widget _stat(String n,String l)=>Expanded(child:Column(children:[Text(n,style:const TextStyle(color:Colors.white,fontSize:25,fontWeight:FontWeight.w900)),Text(l,style:const TextStyle(color:Colors.white70))]));
  Widget _quick(BuildContext c,IconData i,String t,VoidCallback f)=>Card(child:InkWell(onTap:f,borderRadius:BorderRadius.circular(12),child:Padding(padding:const EdgeInsets.all(16),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(i,size:32),const SizedBox(height:8),Text(t,style:const TextStyle(fontWeight:FontWeight.w700))]))));
}

class AnimalsPage extends StatelessWidget {
  const AnimalsPage({super.key});
  @override Widget build(BuildContext context) {
    final s=FarmStore.instance;
    return ListView(padding:const EdgeInsets.all(16),children:[
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
        const Text('Animals & breeding',style:TextStyle(fontSize:22,fontWeight:FontWeight.w800)),
        FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AddAnimalPage())),icon:const Icon(Icons.add),label:const Text('Add')),
      ]),
      const SizedBox(height:12),
      ...animalGroups.entries.map((e)=>Card(child:ListTile(
        leading:CircleAvatar(child:Icon(_animalIcon(e.key))),
        title:Text(e.key,style:const TextStyle(fontWeight:FontWeight.w700)),
        subtitle:Text('${e.value.length} breeds/types • ${s.animals.where((a)=>a['group']==e.key).length} registered'),
        trailing:const Icon(Icons.chevron_right),
        onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>AnimalGroupPage(group:e.key,types:e.value))),
      ))),
      const SizedBox(height:10),
      const Text('Registered animals',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800)),
      const SizedBox(height:8),
      if(s.animals.isEmpty) const Card(child:Padding(padding:EdgeInsets.all(18),child:Text('No animals registered yet. Add your first animal to start breeding and health records.')))
      else ...s.animals.asMap().entries.map((e)=>Card(child:ListTile(
        title:Text('${e.value['name']} • ${e.value['breed']}'),
        subtitle:Text('${e.value['group']} • ${e.value['sex']} • ${e.value['dob']}'),
        trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>s.deleteAnimal(e.key)),
      ))),
    ]);
  }
  IconData _animalIcon(String x){
    if(x.contains('Fish')) return Icons.water;
    if(x.contains('Chickens')||x.contains('Turkeys')||x.contains('Ducks')) return Icons.egg_alt;
    if(x.contains('Dogs')||x.contains('Horses')) return Icons.pets;
    return Icons.agriculture;
  }
}

class AnimalGroupPage extends StatelessWidget {
  final String group; final List<String> types;
  const AnimalGroupPage({super.key,required this.group,required this.types});
  @override Widget build(BuildContext context){
    return Scaffold(appBar:AppBar(title:Text(group)),body:ListView(padding:const EdgeInsets.all(16),children:[
      Text('Breeds & types',style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.bold)),
      const SizedBox(height:8),
      ...types.map((x)=>Card(child:ListTile(leading:const Icon(Icons.check_circle_outline),title:Text(x)))),
      const SizedBox(height:12),
      const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Use the animal profile to record breeding dates, feeding, vaccination, deworming, weight, births and sales. Always confirm veterinary schedules with a qualified Zimbabwe veterinary professional.'))),
    ]));
  }
}

class CropsPage extends StatelessWidget {
  const CropsPage({super.key});
  @override Widget build(BuildContext context){
    final s=FarmStore.instance;
    return ListView(padding:const EdgeInsets.all(16),children:[
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
        const Text('Crops & horticulture',style:TextStyle(fontSize:22,fontWeight:FontWeight.w800)),
        FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AddCropPage())),icon:const Icon(Icons.add),label:const Text('Add')),
      ]),
      const SizedBox(height:12),
      const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Zimbabwe seasonal planner: plan land preparation, planting, fertilising, weeding, irrigation, pest monitoring and harvest around your local conditions.'))),
      const SizedBox(height:12),
      ...cropCatalog.map((c)=>Card(child:ListTile(leading:const Icon(Icons.eco),title:Text(c),subtitle:Text(_seasonAdvice(c)),onTap:()=>_showCrop(context,c)))),
      if(s.crops.isNotEmpty) ...[
        const SizedBox(height:10),const Text('My crop projects',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800)),
        ...s.crops.asMap().entries.map((e)=>Card(child:ListTile(title:Text('${e.value['crop']} • ${e.value['area']} ha'),
          subtitle:Text('Planting: ${e.value['date']}'),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>s.deleteCrop(e.key))))),
      ]
    ]);
  }
  String _seasonAdvice(String c){
    final m=DateTime.now().month;
    if([11,12,1,2].contains(m)) return 'Rainy-season focus: planting/establishment where conditions allow; manage weeds and pests.';
    if([3,4].contains(m)) return 'Late rainy season: crop maintenance, disease/pest checks and harvest planning for early crops.';
    return 'Dry-season focus: irrigation, winter crops, soil preparation and protected horticulture.';
  }
  void _showCrop(BuildContext c,String crop)=>showModalBottomSheet(context:c,showDragHandle:true,builder:(_)=>Padding(padding:const EdgeInsets.all(20),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text(crop,style:const TextStyle(fontSize:24,fontWeight:FontWeight.w800)),const SizedBox(height:10),
    const Text('Plan: site/soil → seed → spacing → fertility → irrigation → weed/pest monitoring → harvest → sales. Exact recommendations should be adapted to your district, variety, soil and water availability.'),
    const SizedBox(height:16),FilledButton(onPressed:()=>Navigator.pop(c),child:const Text('Close'))
  ])));
}

class CalendarPage extends StatelessWidget {
  const CalendarPage({super.key});
  @override Widget build(BuildContext context){
    final s=FarmStore.instance;
    final sorted=[...s.tasks]..sort((a,b)=>('${a['date']}').compareTo('${b['date']}'));
    return ListView(padding:const EdgeInsets.all(16),children:[
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
        const Text('Farm calendar',style:TextStyle(fontSize:22,fontWeight:FontWeight.w800)),
        FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AddTaskPage())),icon:const Icon(Icons.add_alert),label:const Text('Reminder')),
      ]),
      const SizedBox(height:12),
      Card(child:ListTile(leading:const Icon(Icons.notifications_active),title:const Text('Reminders'),subtitle:Text('${s.tasks.length} scheduled farm tasks'))),
      const SizedBox(height:8),
      if(sorted.isEmpty) const Card(child:Padding(padding:EdgeInsets.all(18),child:Text('Examples: broiler vaccination, cow mating check, sow farrowing, fish feeding, tomato fertiliser, irrigation or harvest.')))
      else ...sorted.asMap().entries.map((e)=>Card(child:ListTile(
        leading:const Icon(Icons.event_note),title:Text(e.value['title']??''),subtitle:Text('${e.value['date']} • ${e.value['category']}'),
        trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>s.deleteTask(e.key)),
      )))
    ]);
  }
}

class FarmPage extends StatelessWidget {
  const FarmPage({super.key});
  @override Widget build(BuildContext context){
    final s=FarmStore.instance;
    return ListView(padding:const EdgeInsets.all(16),children:[
      const Text('My Farm',style:TextStyle(fontSize:22,fontWeight:FontWeight.w800)),
      const SizedBox(height:12),
      Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(s.farmer),subtitle:Text(s.province))),
      const SizedBox(height:10),
      Card(child:ListTile(leading:const Icon(Icons.bar_chart),title:const Text('Farm finance'),subtitle:Text('Sales \$${s.sales.toStringAsFixed(2)} • Expenses \$${s.expenses.toStringAsFixed(2)} • Profit \$${(s.sales-s.expenses).toStringAsFixed(2)}'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const FinancePage())))),
      Card(child:ListTile(leading:const Icon(Icons.menu_book),title:const Text('Farming knowledge'),subtitle:const Text('Animal management, crops, horticulture, breeding and record keeping'))),
      Card(child:ListTile(leading:const Icon(Icons.cloud_off),title:const Text('Offline-first'),subtitle:const Text('Core farm records are stored on this device'))),
      Card(child:ListTile(leading:const Icon(Icons.workspace_premium),title:Text(s.pro?'Pro unlocked':'Free plan'),subtitle:Text(s.pro?'All core Pro features unlocked':'Unlock unlimited records and advanced tools'),trailing:s.pro?const Icon(Icons.check_circle):FilledButton(onPressed:()=>showPro(context),child:const Text('UNLOCK')))),
    ]);
  }
}

class AddAnimalPage extends StatefulWidget { const AddAnimalPage({super.key}); @override State<AddAnimalPage> createState()=>_AddAnimalPageState(); }
class _AddAnimalPageState extends State<AddAnimalPage>{
  String group=animalGroups.keys.first, breed=animalGroups.values.first.first, sex='Female';
  final name=TextEditingController(); final dob=TextEditingController(text:DateFormat('yyyy-MM-dd').format(DateTime.now()));
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Add animal')),body:ListView(padding:const EdgeInsets.all(16),children:[
    TextField(controller:name,decoration:const InputDecoration(labelText:'Animal ID / name',prefixIcon:Icon(Icons.tag))),
    const SizedBox(height:12),
    DropdownButtonFormField<String>(value:group,items:animalGroups.keys.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState((){group=v!;breed=animalGroups[group]!.first;}),decoration:const InputDecoration(labelText:'Animal group')),
    const SizedBox(height:12),
    DropdownButtonFormField<String>(value:breed,items:animalGroups[group]!.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>breed=v!),decoration:const InputDecoration(labelText:'Breed / type')),
    const SizedBox(height:12),
    DropdownButtonFormField<String>(value:sex,items:['Female','Male'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>sex=v!),decoration:const InputDecoration(labelText:'Sex')),
    const SizedBox(height:12),
    TextField(controller:dob,decoration:const InputDecoration(labelText:'Date of birth / hatch date')),
    const SizedBox(height:20),
    FilledButton.icon(onPressed:()async{if(name.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter an animal ID or name')));return;}await FarmStore.instance.addAnimal({'name':name.text.trim(),'group':group,'breed':breed,'sex':sex,'dob':dob.text});if(context.mounted)Navigator.pop(context);},icon:const Icon(Icons.save),label:const Text('Save animal')),
  ]));
}

class AddCropPage extends StatefulWidget { const AddCropPage({super.key}); @override State<AddCropPage> createState()=>_AddCropPageState(); }
class _AddCropPageState extends State<AddCropPage>{
  String crop=cropCatalog.first; final area=TextEditingController(text:'1'); final date=TextEditingController(text:DateFormat('yyyy-MM-dd').format(DateTime.now()));
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Add crop project')),body:ListView(padding:const EdgeInsets.all(16),children:[
    DropdownButtonFormField<String>(value:crop,items:cropCatalog.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>crop=v!),decoration:const InputDecoration(labelText:'Crop / horticulture')),
    const SizedBox(height:12),TextField(controller:area,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Area (hectares)')),
    const SizedBox(height:12),TextField(controller:date,decoration:const InputDecoration(labelText:'Planned planting date')),
    const SizedBox(height:20),FilledButton.icon(onPressed:()async{await FarmStore.instance.addCrop({'crop':crop,'area':area.text,'date':date.text});if(context.mounted)Navigator.pop(context);},icon:const Icon(Icons.save),label:const Text('Save crop project'))
  ]));
}

class AddTaskPage extends StatefulWidget { const AddTaskPage({super.key}); @override State<AddTaskPage> createState()=>_AddTaskPageState(); }
class _AddTaskPageState extends State<AddTaskPage>{
  final title=TextEditingController(); String cat='Feeding'; DateTime date=DateTime.now();
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Add farm reminder')),body:ListView(padding:const EdgeInsets.all(16),children:[
    TextField(controller:title,decoration:const InputDecoration(labelText:'Task / reminder',hintText:'e.g. Broiler vaccination')),
    const SizedBox(height:12),
    DropdownButtonFormField<String>(value:cat,items:['Feeding','Vaccination','Deworming','Breeding','Pregnancy','Planting','Fertilising','Irrigation','Weeding','Pest check','Harvest','Sales','Other'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>cat=v!),decoration:const InputDecoration(labelText:'Category')),
    const SizedBox(height:12),
    ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.calendar_today),title:Text(DateFormat('yyyy-MM-dd').format(date)),trailing:FilledButton(onPressed:()async{final d=await showDatePicker(context:context,firstDate:DateTime.now(),lastDate:DateTime.now().add(const Duration(days:3650)),initialDate:date);if(d!=null)setState(()=>date=d);},child:const Text('Choose'))),
    const SizedBox(height:20),FilledButton.icon(onPressed:()async{await FarmStore.instance.addTask({'title':title.text.trim().isEmpty?'Farm task':title.text.trim(),'category':cat,'date':DateFormat('yyyy-MM-dd').format(date)});if(context.mounted)Navigator.pop(context);},icon:const Icon(Icons.notifications_active),label:const Text('Save reminder'))
  ]));
}

class FinancePage extends StatefulWidget { const FinancePage({super.key}); @override State<FinancePage> createState()=>_FinancePageState(); }
class _FinancePageState extends State<FinancePage>{
  final amount=TextEditingController(); 
  @override Widget build(BuildContext context){final s=FarmStore.instance;return Scaffold(appBar:AppBar(title:const Text('Farm finance')),body:ListView(padding:const EdgeInsets.all(16),children:[
    Card(child:ListTile(title:const Text('Sales'),trailing:Text('\$${s.sales.toStringAsFixed(2)}'))),
    Card(child:ListTile(title:const Text('Expenses'),trailing:Text('\$${s.expenses.toStringAsFixed(2)}'))),
    Card(child:ListTile(title:const Text('Profit'),trailing:Text('\$${(s.sales-s.expenses).toStringAsFixed(2)}',style:const TextStyle(fontWeight:FontWeight.w800)))),
    const SizedBox(height:16),TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Amount USD')),
    const SizedBox(height:10),Row(children:[Expanded(child:FilledButton(onPressed:(){final v=double.tryParse(amount.text)??0;s.addExpense(v);amount.clear();},child:const Text('Add expense'))),const SizedBox(width:10),Expanded(child:OutlinedButton(onPressed:(){final v=double.tryParse(amount.text)??0;s.addSale(v);amount.clear();},child:const Text('Add sale')))])
  ]));}
}

void showPro(BuildContext context){
  final s=FarmStore.instance;
  showModalBottomSheet(context:context,isScrollControlled:true,showDragHandle:true,builder:(c)=>Padding(padding:const EdgeInsets.fromLTRB(20,8,20,24),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
    const Text('👑 Smart Farmer ZW Pro',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900)),
    const SizedBox(height:8),const Text('Lifetime access • once-off \$5',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700)),
    const SizedBox(height:12),
    const Text('✓ Unlimited animal & crop records\n✓ Breeding & farm calendar tools\n✓ Feeding, vaccination & task reminders\n✓ Finance, sales & profit tracking\n✓ Zimbabwe seasonal planning\n✓ Future cloud backup & advanced tools'),
    const SizedBox(height:18),
    SizedBox(width:double.infinity,child:FilledButton.icon(
      onPressed:()async{
        // Production billing hook: configure product ID smart_farmer_pro in Google Play Console.
        // This demo unlocks locally so the UI can be tested before Play Billing credentials/products exist.
        await s.unlockDemoPro();
        if(c.mounted)Navigator.pop(c);
        if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Pro demo unlocked. Connect Google Play Billing before publishing.')));
      },icon:const Icon(Icons.workspace_premium),label:const Text('UNLOCK PRO — \$5'))),
    const SizedBox(height:8),const Text('For the public release, replace the demo unlock with a verified Google Play one-time purchase for product ID smart_farmer_pro.',style:TextStyle(fontSize:12,color:Colors.grey)),
  ]));
}
